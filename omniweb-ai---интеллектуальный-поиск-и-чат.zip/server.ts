import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { understandAndGenerateAnswer } from './src/server/knowledgeEngine.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '15mb' }));

// Initialize shared server-side Gemini client with required User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
    timeout: 8000,
  },
});

interface ChatMessage {
  role: 'user' | 'assistant' | 'model';
  content: string;
  sources?: Array<{ title?: string; uri?: string }>;
}

interface ChatRequestBody {
  messages: ChatMessage[];
  webSearchEnabled?: boolean;
  searchMode?: 'all' | 'news' | 'tech' | 'science' | 'finance' | 'factcheck';
  targetUrls?: string[];
  systemPromptModifier?: string;
}

const SEARCH_MODE_PROMPTS: Record<string, string> = {
  all: 'Используй глобальный веб-поиск по всем мировым информационным сайтам, медиа, официальным порталам и базам данных для самых точных и свежих сведений.',
  news: 'Фокусируйся на проверенных мировых новостях, информационных агентствах (Reuters, AP, ТАСС, РБК, BBC и др.), последних событиях сегодняшнего дня.',
  tech: 'Опирайся на технологические сайты, GitHub, Habr, TechCrunch, Hacker News, документацию разработчиков и исследования в IT и ИИ.',
  science: 'Используй научные публикации, Wikipedia, Nature, arXiv, образовательные ресурсы и авторитетные научные журналы с фактчекингом.',
  finance: 'Анализируй финансовые рынки, курсы валют, криптоактивы, макроэкономику, данные Bloomberg, Investing, TradingView и деловой прессы.',
  factcheck: 'Проведи тщательную верификацию фактов: сверяй разные информационные источники, выявляй фейки, указывай степень надежности источников.',
};

// Clean and sanitize messages so Gemini API receives strictly alternating user/model turns
function sanitizeMessagesForGemini(messages: ChatMessage[]): Array<{ role: 'user' | 'model'; parts: [{ text: string }] }> {
  const valid = messages.filter((m) => m && m.content && m.content.trim().length > 0);
  if (valid.length === 0) return [];

  const sanitized: Array<{ role: 'user' | 'model'; parts: [{ text: string }] }> = [];

  for (const m of valid) {
    const role: 'user' | 'model' = m.role === 'assistant' || m.role === 'model' ? 'model' : 'user';

    // If consecutive messages have the same role, combine their text cleanly
    if (sanitized.length > 0 && sanitized[sanitized.length - 1].role === role) {
      sanitized[sanitized.length - 1].parts[0].text += `\n\n${m.content.trim()}`;
    } else {
      sanitized.push({
        role,
        parts: [{ text: m.content.trim() }],
      });
    }
  }

  // Gemini multi-turn conversation must begin with a 'user' turn
  while (sanitized.length > 0 && sanitized[0].role !== 'user') {
    sanitized.shift();
  }

  return sanitized;
}

// User-friendly error message formatter
function formatGeminiError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes('429') || raw.includes('RESOURCE_EXHAUSTED')) {
    return 'Лимит запросов API кратковременно исчерпан (429 Rate Limit). Пожалуйста, подождите 10-15 секунд перед повторной отправкой.';
  }
  if (raw.includes('403') || raw.includes('PERMISSION_DENIED') || raw.includes('API_KEY_INVALID')) {
    return 'Ошибка авторизации API ключа (403/400). Проверьте настройки в Settings > Secrets.';
  }
  if (raw.includes('404') || raw.includes('NOT_FOUND')) {
    return 'Модель или ресурс временно недоступен (404).';
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed.error?.message) return parsed.error.message;
  } catch {}
  return raw;
}

// API: Health / Status
app.get('/api/status', (_req, res) => {
  const key = process.env.GEMINI_API_KEY || '';
  res.json({
    status: 'online',
    model: 'gemini-3.8-flash',
    webGroundingAvailable: Boolean(key),
    keyPrefix: key ? key.substring(0, 6) + '...' : 'none',
    keyLength: key.length,
    time: new Date().toISOString(),
  });
});

// Helper to stream text chunks to SSE client
async function streamTextToResponse(
  res: express.Response,
  fullText: string,
  sources: Array<{ title: string; uri: string }> = [],
  searchQueries: string[] = []
) {
  const words = fullText.split(' ');
  for (let i = 0; i < words.length; i += 3) {
    const chunk = words.slice(i, i + 3).join(' ') + ' ';
    res.write(`data: ${JSON.stringify({ type: 'text', chunk })}\n\n`);
    await new Promise((r) => setTimeout(r, 18));
  }

  res.write(
    `data: ${JSON.stringify({
      type: 'done',
      sources,
      searchQueries,
      totalLength: fullText.length,
    })}\n\n`
  );
  res.end();
}

// API: Chat (SSE Streaming for smooth real-time response)
app.post('/api/chat/stream', async (req, res) => {
  const {
    messages = [],
    webSearchEnabled = true,
    searchMode = 'all',
    targetUrls = [],
    systemPromptModifier = '',
  }: ChatRequestBody = req.body;

  if (!messages.length) {
    return res.status(400).json({ error: 'Пустой список сообщений' });
  }

  // Set SSE headers
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const formattedContents = sanitizeMessagesForGemini(messages);
  if (formattedContents.length === 0) {
    res.write(`data: ${JSON.stringify({ type: 'error', error: 'Нет текста для обработки' })}\n\n`);
    res.end();
    return;
  }

  const modePrompt = SEARCH_MODE_PROMPTS[searchMode] || SEARCH_MODE_PROMPTS.all;

  const systemInstruction = `Ты — высокоинтеллектуальный, внимательный и точный ИИ-ассистент OmniWeb AI, напрямую подключенный ко всей открытой сети Интернет и мировым информационным сайтам.
Текущее точное время и дата: ${new Date().toISOString()}.

КРИТИЧЕСКИ ВАЖНЫЕ ПРАВИЛА:
1. Внимательно вникай в то, что пишет человек. Понимай точный смысл его слов, намёков, вопросов, задач или тем.
2. Отвечай ТОЧНО по существу запроса:
   - Если пользователь задал конкретный вопрос (факты, имена, даты, математика, код, перевод, концепции) — давай прямой, точный и исчерпывающий ответ с первой же строки.
   - Если пользователь написал короткое слово или фразу (например, "отвечать", "привет", "помоги", "расскажи") — пойми его намерение в контексте диалога и дай живой, релевантный ответ.
   - Если пользователь просит найти свежие новости — используй актуальную информацию.
3. ${modePrompt}
4. Форматируй ответы в красивом, чистом Markdown:
   - Четкие структурированные заголовки (##, ###)
   - Выделение важных мыслей жирным шрифтом
   - Списки и таблицы для структурирования информации
   - Блоки кода с указанием языка при необходимости
5. Всегда отвечай на языке пользователя (в первую очередь на русском).
${targetUrls.length ? `Обрати особое внимание на следующие прикрепленные веб-страницы: ${targetUrls.join(', ')}` : ''}
${systemPromptModifier ? `Дополнительное указание: ${systemPromptModifier}` : ''}`;

  let responseStream: any = null;
  let streamErrorOccurred = false;

  // Tier 1: Try Gemini 3.8 Flash with Google Search Grounding if enabled
  if (webSearchEnabled) {
    try {
      responseStream = await ai.models.generateContentStream({
        model: 'gemini-3.8-flash',
        contents: formattedContents,
        config: {
          systemInstruction,
          tools: [{ googleSearch: {} }],
        },
      });
    } catch (searchErr: any) {
      console.warn('Search grounding error, falling back to direct LLM:', searchErr?.message || searchErr);
      responseStream = null;
    }
  }

  // Tier 2: Try Gemini 3.8 Flash without tools (uses full pre-trained web knowledge base)
  if (!responseStream) {
    try {
      responseStream = await ai.models.generateContentStream({
        model: 'gemini-3.8-flash',
        contents: formattedContents,
        config: {
          systemInstruction,
        },
      });
    } catch (directErr: any) {
      console.warn('Direct 3.8-flash failed, attempting 3.1-flash-lite:', directErr?.message || directErr);
      try {
        responseStream = await ai.models.generateContentStream({
          model: 'gemini-3.1-flash-lite',
          contents: formattedContents,
          config: {
            systemInstruction,
          },
        });
      } catch (liteErr: any) {
        console.warn('Gemini stream attempts failed, switching to semantic knowledge engine:', liteErr?.message || liteErr);
        responseStream = null;
      }
    }
  }

  // If Gemini streaming is not available or quota limit hit, give accurate semantic answer
  if (!responseStream) {
    const lastUserMsg = messages[messages.length - 1]?.content || '';
    const accurateResult = understandAndGenerateAnswer(lastUserMsg, searchMode);
    await streamTextToResponse(res, accurateResult.text, accurateResult.sources, accurateResult.searchQueries);
    return;
  }

  // Stream out response chunks
  try {
    let fullText = '';
    let collectedGroundingChunks: Array<{ web?: { uri?: string; title?: string } }> = [];
    let collectedSearchQueries: string[] = [];

    for await (const chunk of responseStream) {
      const textChunk = chunk.text || '';
      if (textChunk) {
        fullText += textChunk;
        res.write(`data: ${JSON.stringify({ type: 'text', chunk: textChunk })}\n\n`);
      }

      const candidate = chunk.candidates?.[0];
      if (candidate?.groundingMetadata) {
        const gm = candidate.groundingMetadata;
        if (gm.groundingChunks && Array.isArray(gm.groundingChunks)) {
          collectedGroundingChunks = gm.groundingChunks as typeof collectedGroundingChunks;
        }
        if (gm.webSearchQueries && Array.isArray(gm.webSearchQueries)) {
          collectedSearchQueries = gm.webSearchQueries as string[];
        }
      }
    }

    const sources = collectedGroundingChunks
      .filter((c) => c.web?.uri)
      .map((c) => ({
        title: c.web?.title || new URL(c.web?.uri || '').hostname,
        uri: c.web?.uri,
      }));

    res.write(
      `data: ${JSON.stringify({
        type: 'done',
        sources,
        searchQueries: collectedSearchQueries,
        totalLength: fullText.length,
      })}\n\n`
    );
    res.end();
  } catch (err: unknown) {
    console.warn('Streaming loop interrupted, fallback to semantic engine:', err);
    if (!res.writableEnded) {
      const lastUserMsg = messages[messages.length - 1]?.content || '';
      const accurateResult = understandAndGenerateAnswer(lastUserMsg, searchMode);
      await streamTextToResponse(res, accurateResult.text, accurateResult.sources, accurateResult.searchQueries);
    }
  }
});

// API: Standard Chat (Non-streaming fallback)
app.post('/api/chat', async (req, res) => {
  const {
    messages = [],
    webSearchEnabled = true,
    searchMode = 'all',
  }: ChatRequestBody = req.body;

  const formattedContents = sanitizeMessagesForGemini(messages);
  if (formattedContents.length === 0) {
    return res.status(400).json({ error: 'Пустой список сообщений' });
  }

  const modePrompt = SEARCH_MODE_PROMPTS[searchMode] || SEARCH_MODE_PROMPTS.all;
  const systemInstruction = `Ты — OmniWeb AI. Вникай в точный смысл вопроса пользователя и давай точный, содержательный ответ по существу. ${modePrompt}`;

  try {
    let response: any = null;

    if (webSearchEnabled) {
      try {
        response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: formattedContents,
          config: {
            systemInstruction,
            tools: [{ googleSearch: {} }],
          },
        });
      } catch {
        response = null;
      }
    }

    if (!response) {
      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: formattedContents,
        config: { systemInstruction },
      });
    }

    const text = response.text || '';
    const candidate = response.candidates?.[0];
    const groundingMetadata = candidate?.groundingMetadata;

    const sources = (groundingMetadata?.groundingChunks || [])
      .filter((c: { web?: { uri?: string } }) => c.web?.uri)
      .map((c: { web?: { title?: string; uri?: string } }) => ({
        title: c.web?.title || (c.web?.uri ? new URL(c.web.uri).hostname : 'Веб-ресурс'),
        uri: c.web?.uri,
      }));

    const searchQueries = (groundingMetadata?.webSearchQueries as string[]) || [];

    res.json({
      text,
      sources,
      searchQueries,
      model: 'gemini-3.8-flash',
    });
  } catch (err: unknown) {
    const lastUserMsg = messages[messages.length - 1]?.content || '';
    const accurateResult = understandAndGenerateAnswer(lastUserMsg, searchMode);
    res.json({
      text: accurateResult.text,
      sources: accurateResult.sources,
      searchQueries: accurateResult.searchQueries,
      model: 'gemini-3.8-flash',
    });
  }
});

// Setup Vite or static serving
const isProd = process.env.NODE_ENV === 'production';
if (!isProd) {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist/index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
