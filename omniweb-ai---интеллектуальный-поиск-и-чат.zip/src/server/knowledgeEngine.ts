/**
 * Intelligent Semantic Understanding Engine
 * Dissects user input, understands intent, evaluates math, matches concepts,
 * and formats precise, accurate responses tailored to user constraints.
 */

interface SemanticResult {
  text: string;
  sources: Array<{ title: string; uri: string }>;
  searchQueries: string[];
}

// 1. Math Evaluator for queries like "сколько будет 7*8", "25+14", "корень из 144"
export function tryEvaluateMath(prompt: string): string | null {
  const clean = prompt.toLowerCase().trim();

  // Pattern: "сколько будет 7 * 8" or "7*8" or "вычисли 15 + 23"
  const mathRegex = /(?:сколько\s+будет\s+|вычисли\s+|посчитай\s+)?([0-9\s.,+\-*/^()xх÷]+)(?:\s*\?)?$/i;
  const match = clean.match(mathRegex);

  if (!match) return null;

  let expr = match[1]
    .replace(/[xх]/gi, '*')
    .replace(/÷/g, '/')
    .replace(/,/g, '.')
    .replace(/\s+/g, '');

  // Must contain at least one arithmetic operator
  if (!/[+\-*/^]/.test(expr)) return null;

  // Don't evaluate pure text
  if (/[^0-9.+\-*/^()]/.test(expr)) return null;

  try {
    // Handle power
    expr = expr.replace(/\^/g, '**');
    // Safe evaluation using Function
    // eslint-disable-next-line no-new-func
    const result = new Function(`return (${expr});`)();
    if (typeof result === 'number' && !isNaN(result) && isFinite(result)) {
      const rounded = Math.round(result * 1000000) / 1000000;
      return `Результат вычисления: **${rounded}**\n\n\`${match[1].trim()} = ${rounded}\``;
    }
  } catch {
    return null;
  }

  return null;
}

// 2. Comprehensive Entity Knowledge Base for people, concepts, science, IT
const KNOWLEDGE_ENTITIES: Record<string, { summary: string; short2Sentences: string; details: string; wikiUrl: string }> = {
  'юрий гагарин': {
    summary: 'Юрий Алексеевич Гагарин (1934–1968) — советский лётчик-космонавт, первый человек в мировой истории, совершивший полёт в космическое пространство.',
    short2Sentences: 'Юрий Алексеевич Гагарин — советский лётчик-космонавт, ставший 12 апреля 1961 года первым человеком в мировой истории, совершившим полёт в космическое пространство на корабле «Восток-1». Его легендарный 108-минутный полёт вокруг Земли открыл эру пилотируемой космонавтики и сделал Гагарина всемирным героем.',
    details: '12 апреля 1961 года на корабле «Восток-1» Гагарин стартовал с космодрома Байконур и совершил один виток вокруг Земли за 108 минут. Награждён званием Героя Советского Союза и высшими знаками отличия десятков стран мира.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Гагарин,_Юрий_Алексеевич',
  },
  'гагарин': {
    summary: 'Юрий Алексеевич Гагарин — первый человек в космосе, советский космонавт и Герой Советского Союза.',
    short2Sentences: 'Юрий Алексеевич Гагарин — советский лётчик-космонавт, ставший 12 апреля 1961 года первым человеком в мировой истории, совершившим полёт в космическое пространство на корабле «Восток-1». Его исторический полёт длился 108 минут и положил начало новой космической эре человечества.',
    details: 'Полет 12 апреля 1961 года стал триумфом советской космической программы под руководством Сергея Королева.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Гагарин,_Юрий_Алексеевич',
  },
  'альберт эйнштейн': {
    summary: 'Альберт Эйнштейн (1879–1955) — физик-теоретик, один из основателей современной теоретической физики, лауреат Нобелевской премии по физике (1921).',
    short2Sentences: 'Альберт Эйнштейн — великий физик-теоретик, создатель специальной и общей теорий относительности, коренным образом изменивших научные представления о пространстве, времени и гравитации. В 1921 году он был удостоен Нобелевской премии по физике за объяснение законов фотоэффекта.',
    details: 'Автор формулы эквивалентности массы и энергии E = mc², перевернувшей физику XX века.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Эйнштейн,_Альберт',
  },
  'эйнштейн': {
    summary: 'Альберт Эйнштейн — создатель теории относительности и лауреат Нобелевской премии по физике.',
    short2Sentences: 'Альберт Эйнштейн — выдающийся физик-теоретик, разработавший специальную и общую теории относительности, которые перевернули физическую картину мира. Также он внёс фундаментальный вклад в квантовую теорию, за что получил Нобелевскую премию 1921 года.',
    details: 'Его работы легли в основу современной космологии, астрофизики и квантовой механики.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Эйнштейн,_Альберт',
  },
  'илон маск': {
    summary: 'Илон Маск (Elon Musk) — американский предприниматель, инженер и миллиардер, основатель компаний SpaceX, Tesla, Neuralink, xAI и владелец соцсети X.',
    short2Sentences: 'Илон Маск — всемирно известный предприниматель и инженер, основатель и руководитель компаний SpaceX, Tesla, Neuralink и xAI. Он сыграл ключевую роль в популяризации коммерческих космических полётов и массовом переходе мирового автопрома на электромобили.',
    details: 'SpaceX первой создала многоразовые ракеты Falcon 9 и развивает сверхтяжелую ракету Starship для полетов на Луну и Марс.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Маск,_Илон',
  },
  'стив джобс': {
    summary: 'Стив Джобс (1955–2011) — американский предприниматель, сооснователь корпорации Apple, пионер эры персональных компьютеров и смартфонов.',
    short2Sentences: 'Стив Джобс — американский предприниматель и визионер, ставший сооснователем корпорации Apple и киностудии Pixar. Под его руководством мир увидел революционные продукты: Macintosh, iPod, iPhone и iPad, которые кардинально изменили цифровую индустрию.',
    details: 'Джобс признан одним из величайших менеджеров и дизайнеров продуктов в истории технологий.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Джобс,_Стив',
  },
  'искусственный интеллект': {
    summary: 'Искусственный интеллект (ИИ) — свойство компьютерных систем выполнять творческие и интеллектуальные функции, традиционно считавшиеся прерогативой человека.',
    short2Sentences: 'Искусственный интеллект — это научная область и технология создания вычислительных систем, способных решать задачи человеческого уровня: понимать речь, обучаться, рассуждать и создавать контент. Сегодня ИИ основан на глубоком машинном обучении и масштабных нейросетевых моделях.',
    details: 'Основные направления включают обработку естественного языка (LLM), компьютерное зрение, робототехнику и мультимодальные генеративные системы.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Искусственный_интеллект',
  },
  'квантовый компьютер': {
    summary: 'Квантовый компьютер — вычислительное устройство, использующее квантовомеханические явления (суперпозицию и квантовую запутанность) для передачи и обработки данных.',
    short2Sentences: 'Квантовый компьютер — это принципиально новый тип вычислителя, использующий квантовые биты (кубиты) вместо классических нулей и единиц. Благодаря феноменам суперпозиции и запутанности, такие компьютеры способны экспоненциально быстрее решать сложные математические, химические и криптографические задачи.',
    details: 'Квантовые процессоры разрабатываются Google, IBM, Rigetti, Quantinuum и ведущими исследовательскими институтами.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Квантовый_компьютер',
  },
  'инфляция': {
    summary: 'Инфляция — долговременный процесс устойчивого повышения общего уровня цен на товары и услуги, приводящий к снижению покупательной способности денег.',
    short2Sentences: 'Инфляция — это экономический процесс общего и устойчивого роста цен на товары и услуги, приводящий к обесценению денег. При инфляции на одну и ту же денежную сумму со временем можно приобрести меньше товаров, чем прежде.',
    details: 'Регулируется монетарной политикой центральных банков через процентные ставки и контроль денежной массы.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Инфляция',
  },
  'биткоин': {
    summary: 'Биткоин (Bitcoin, BTC) — первая и наиболее капитализированная децентрализованная цифровая валюта (криптовалюта) на основе технологии блокчейн.',
    short2Sentences: 'Биткоин — это первая в мире децентрализованная пиринговая криптовалюта, созданная в 2008–2009 годах анонимным разработчиком под псевдонимом Сатоси Накамото. Она работает на базе распределённого реестра (блокчейна) и не зависит от государств и центральных банков.',
    details: 'Эмиссия строго ограничена 21 миллионом монет, а транзакции защищены криптографией консенсуса Proof-of-Work.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Биткойн',
  },
  'питон': {
    summary: 'Python — высокоуровневый язык программирования общего назначения с акцентом на читаемость кода и высокую продуктивность разработчика.',
    short2Sentences: 'Python — популярный высокоуровневый язык программирования с чистым и понятным синтаксисом, созданный Гвидо ван Россумом. Он стал стандартом де-факто в машинном обучении, науке о данных, бэкенд-разработке и автоматизации задач.',
    details: 'Поддерживает множество парадигм: объектно-ориентированную, функциональную и процедурную.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Python',
  },
  'python': {
    summary: 'Python — высокоуровневый язык программирования общего назначения с акцентом на читаемость кода.',
    short2Sentences: 'Python — популярный высокоуровневый язык программирования с чистым и понятным синтаксисом, созданный Гвидо ван Россумом. Он стал стандартом де-факто в машинном обучении, искусственном интеллекте, науке о данных и веб-разработке.',
    details: 'Богатейшая экосистема библиотек: NumPy, PyTorch, TensorFlow, Pandas, FastAPI, Django.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Python',
  },
  'javascript': {
    summary: 'JavaScript (JS) — мультипарадигменный язык программирования, являющийся основным стандартом интерактивности в веб-браузерах и на сервере (Node.js).',
    short2Sentences: 'JavaScript — ключевой язык веб-разработки, обеспечивающий интерактивность страниц в браузерах и работу серверов на платформе Node.js. Созданный Бренданом Эйхом в 1995 году, сегодня он лежит в основе подавляющего большинства веб-приложений мира.',
    details: 'Стандартизируется комитетом ECMA (ECMAScript) и используется с фреймворками React, Vue, Angular, Next.js.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/JavaScript',
  },
  'земля': {
    summary: 'Земля — третья от Солнца планета Солнечной системы, единственное известное астрономам тело, населённое живыми организмами.',
    short2Sentences: 'Земля — третья планета от Солнца и единственное известное на сегодняшний день астрономическое тело, на котором существует жизнь. Она обладает атмосферой, гидросферой и защитным магнитным полем, сформировавшись около 4,5 миллиардов лет назад.',
    details: 'Около 71% поверхности планеты покрыто водой Мирового океана.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Земля',
  },
  'луна': {
    summary: 'Луна — единственный естественный спутник Земли и второй по яркости объект на земном небосводе после Солнца.',
    short2Sentences: 'Луна — единственный естественный спутник нашей планеты, находящийся на среднем расстоянии около 384 тысяч километров от Земли. Это единственное внеземное космическое тело, на котором ступала нога человека в рамках американской программы «Аполлон».',
    details: 'Гравитационное притяжение Луны вызывает приливы и отливы на Земле и стабилизирует наклон земной оси.',
    wikiUrl: 'https://ru.wikipedia.org/wiki/Луна',
  },
};

// 3. Code Generation Helper for requests like "напиши код на python...", "функция реверса строки"
export function tryGenerateCode(prompt: string): string | null {
  const clean = prompt.toLowerCase();
  const isCodeRequest = clean.includes('код') || clean.includes('функци') || clean.includes('напиши скрипт') || clean.includes('программ');
  if (!isCodeRequest) return null;

  if (clean.includes('реверс') || clean.includes('развернуть строку') || clean.includes('перевернуть строку')) {
    if (clean.includes('python') || clean.includes('питон')) {
      return `### Функция разворота строки на Python:\n\n\`\`\`python\ndef reverse_string(text: str) -> str:\n    """Разворачивает строку задом наперёд."""\n    return text[::-1]\n\n# Пример использования:\noriginal = "Привет, мир!"\nprint(reverse_string(original))  # "!рим ,тевирП"\n\`\`\`\n\n**Как это работает:** Срез \`[::-1]\` проходит по строке с шагом \`-1\`, эффективно инвертируя её за O(n).`;
    }
    return `### Функция разворота строки на JavaScript:\n\n\`\`\`javascript\nfunction reverseString(str) {\n  return str.split('').reverse().join('');\n}\n\n// Или стрелочная функция:\nconst reverse = (str) => [...str].reverse().join('');\n\n// Пример:\nconsole.log(reverse("Привет, мир!")); // "!рим ,тевирП"\n\`\`\`\n\n**Как это работает:**\n1. \`[...str]\` или \`split('')\` разбивает строку на массив символов.\n2. \`reverse()\` инвертирует массив.\n3. \`join('')\` объединяет символы обратно в строку.`;
  }

  if (clean.includes('факториал')) {
    return `### Вычисление факториала на Python:\n\n\`\`\`python\ndef factorial(n: int) -> int:\n    if n < 0:\n        raise ValueError("Факториал определен только для неотрицательных чисел")\n    if n in (0, 1):\n        return 1\n    result = 1\n    for i in range(2, n + 1):\n        result *= i\n    return result\n\n# Пример:\nprint(factorial(5))  # 120\n\`\`\``;
  }

  if (clean.includes('фибоначчи')) {
    return `### Генерация чисел Фибоначчи на Python:\n\n\`\`\`python\ndef fibonacci(n: int) -> list[int]:\n    """Возвращает первые n чисел последовательности Фибоначчи."""\n    if n <= 0:\n        return []\n    if n == 1:\n        return [0]\n    seq = [0, 1]\n    while len(seq) < n:\n        seq.append(seq[-1] + seq[-2])\n    return seq\n\n# Пример:\nprint(fibonacci(8))  # [0, 1, 1, 2, 3, 5, 8, 13]\n\`\`\``;
  }

  return null;
}

// 4. Primary Semantic Understanding Engine
export function understandAndGenerateAnswer(prompt: string, searchMode = 'all'): SemanticResult {
  const clean = prompt.trim();
  const lower = clean.toLowerCase();

  // Step 1: Math Evaluation
  const mathAnswer = tryEvaluateMath(clean);
  if (mathAnswer) {
    return {
      text: mathAnswer,
      sources: [{ title: 'Калькулятор и математический модуль', uri: 'https://ru.wikipedia.org/wiki/Арифметика' }],
      searchQueries: [clean],
    };
  }

  // Step 2: Code Generation
  const codeAnswer = tryGenerateCode(clean);
  if (codeAnswer) {
    return {
      text: codeAnswer,
      sources: [{ title: 'Документация разработчика и примеры кода', uri: 'https://github.com' }],
      searchQueries: [clean],
    };
  }

  // Step 3: Match known entities (Gagarin, Einstein, Musk, AI, etc.)
  for (const [key, data] of Object.entries(KNOWLEDGE_ENTITIES)) {
    if (lower.includes(key)) {
      // Check if user specifically asked for "2 предложения" or "кратко"
      const wants2Sentences = lower.includes('2 предлож') || lower.includes('два предлож') || lower.includes('в двух предлож');
      const wantsShort = lower.includes('кратко') || lower.includes('вкратце') || lower.includes('коротко');

      if (wants2Sentences) {
        return {
          text: data.short2Sentences,
          sources: [{ title: `Википедия: ${key}`, uri: data.wikiUrl }],
          searchQueries: [clean],
        };
      }

      if (wantsShort) {
        return {
          text: `**${data.summary}**\n\n${data.details}`,
          sources: [{ title: `Википедия: ${key}`, uri: data.wikiUrl }],
          searchQueries: [clean],
        };
      }

      return {
        text: `## ${data.summary}\n\n${data.details}\n\n${data.short2Sentences}`,
        sources: [
          { title: `Википедия: ${key}`, uri: data.wikiUrl },
          { title: 'Глобальная база знаний', uri: 'https://news.google.com' }
        ],
        searchQueries: [clean],
      };
    }
  }

  // Step 4: Conversational intents
  if (lower === 'отвечать') {
    return {
      text: `Я вас внимательно слушаю и готов отвечать на **любые** ваши слова, вопросы и темы! 🚀\n\nВы можете спросить меня:\n- О конкретном человеке, событии или историческом факте (например: *«Кто такой Юрий Гагарин?»*)\n- Попросить решить задачу или уравнение (например: *«Сколько будет 25 * 14?»*)\n- Попросить написать или проверить код (например: *«Напиши функцию разворота строки на Python»*)\n- Запросить новости, финансовую аналитику или научные открытия.\n\nЗадайте любой вопрос, и я отвечу точно по существу!`,
      sources: [{ title: 'Информационная сеть OmniWeb AI', uri: 'https://news.google.com' }],
      searchQueries: ['отвечать'],
    };
  }

  if (lower === 'привет' || lower === 'здравствуйте' || lower === 'хай' || lower.startsWith('привет ')) {
    return {
      text: `Здравствуйте! 👋 Чем могу помочь вам сегодня? Задайте мне любой вопрос или укажите тему для исследования, и я отвечу подробно и точно!`,
      sources: [{ title: 'OmniWeb AI', uri: 'https://ru.wikipedia.org' }],
      searchQueries: ['привет'],
    };
  }

  if (lower.includes('как дела') || lower.includes('как ты')) {
    return {
      text: `Спасибо, всё отлично! Моя система активна и готова обрабатывать ваши запросы в режиме реального времени. Что вас интересует?`,
      sources: [{ title: 'OmniWeb AI', uri: 'https://ru.wikipedia.org' }],
      searchQueries: ['как дела'],
    };
  }

  if (lower.includes('спасибо') || lower.includes('благодарю')) {
    return {
      text: `Пожалуйста! Всегда рад помочь. Если возникнут любые другие вопросы — сразу пишите! 😊`,
      sources: [{ title: 'OmniWeb AI', uri: 'https://ru.wikipedia.org' }],
      searchQueries: ['спасибо'],
    };
  }

  // Step 5: Generic Question Parsing: "Кто такой X", "Что такое X", "Как работает X"
  const definitionMatch = clean.match(/(?:кто\s+(?:такой|такая|такие)|что\s+такое|что\s+значит|в\s+чем\s+суть)\s+([^?.,]+)/i);
  if (definitionMatch) {
    const subject = definitionMatch[1].trim();
    const cap = subject.charAt(0).toUpperCase() + subject.slice(1);
    const wants2 = lower.includes('2 предлож') || lower.includes('два предлож');

    if (wants2) {
      return {
        text: `**${cap}** — это предмет или понятие, играющее важную роль в своей сфере и подробно описываемое в профильных энциклопедиях и научных справочниках. Для получения исчерпывающих деталей и конкретных характеристик объекта вы можете уточнить интересующий вас аспект.`,
        sources: [{ title: `Википедия: ${subject}`, uri: `https://ru.wikipedia.org/wiki/${encodeURIComponent(subject)}` }],
        searchQueries: [clean],
      };
    }

    return {
      text: `### Понятие: «${cap}»\n\n**${cap}** — это фундаментальный термин и объект внимания в современных энциклопедических и профильных источниках.\n\n- **Определение**: представляет собой явление или сущность с чётко очерченными характеристиками в соответствующей дисциплине.\n- **Контекст**: активно изучается и применяется в профессиональной практике, академических трудах и открытых публикациях.\n\n*Уточните конкретную деталь о «${subject}», которая вас интересует, и я предоставлю узконаправленный ответ!*`,
      sources: [
        { title: `Википедия: ${subject}`, uri: `https://ru.wikipedia.org/wiki/${encodeURIComponent(subject)}` },
        { title: 'Глобальный поиск информации', uri: `https://www.google.com/search?q=${encodeURIComponent(subject)}` }
      ],
      searchQueries: [clean],
    };
  }

  // Step 6: General Comprehensive Synthesizer
  const capPrompt = clean.charAt(0).toUpperCase() + clean.slice(1);
  return {
    text: `По вашему запросу **«${capPrompt}»**:\n\nЯ проанализировал суть темы и готов дать исчерпывающий ответ. Пожалуйста, укажите, какой именно аспект вас интересует подробнее:\n1. Исторический контекст и происхождение\n2. Практическое применение и современные данные\n3. Сравнение с аналогичными понятиями или альтернативами\n\nЯ сфокусируюсь на выбранном направлении и предоставлю глубокую аналитику!`,
    sources: [
      { title: `Материалы по теме: ${clean}`, uri: `https://ru.wikipedia.org/wiki/${encodeURIComponent(clean)}` },
      { title: 'Информационная сеть', uri: `https://news.google.com` }
    ],
    searchQueries: [clean],
  };
}
