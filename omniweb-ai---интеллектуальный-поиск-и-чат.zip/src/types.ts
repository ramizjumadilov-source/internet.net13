export type SearchMode = 'all' | 'news' | 'tech' | 'science' | 'finance' | 'factcheck';

export interface GroundingSource {
  title?: string;
  uri?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  sources?: GroundingSource[];
  searchQueries?: string[];
  searchMode?: SearchMode;
  targetUrls?: string[];
  isStreaming?: boolean;
  error?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  searchMode: SearchMode;
  webSearchEnabled: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface TrendingTopic {
  id: string;
  category: string;
  icon: string;
  title: string;
  prompt: string;
}
