/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Square,
  Mic,
  MicOff,
  Globe,
  Link2,
  ArrowDown,
  Sparkles,
  AlertCircle,
  X,
} from 'lucide-react';
import { ChatSession, Message, SearchMode } from './types';
import {
  createNewSession,
  loadSavedSessions,
  saveSessions,
  getActiveSessionId,
  setActiveSessionId,
} from './utils/storage';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { ChatMessageItem } from './components/ChatMessageItem';
import { TrendingTopics } from './components/TrendingTopics';
import { UrlInputModal } from './components/UrlInputModal';

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const saved = loadSavedSessions();
    if (saved.length > 0) return saved;
    const initial = createNewSession('Первый диалог');
    saveSessions([initial]);
    return [initial];
  });

  const [activeId, setActiveId] = useState<string>(() => {
    const savedId = getActiveSessionId();
    if (savedId && sessions.some((s) => s.id === savedId)) {
      return savedId;
    }
    return sessions[0]?.id || '';
  });

  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isUrlModalOpen, setIsUrlModalOpen] = useState(false);
  const [targetUrls, setTargetUrls] = useState<string[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const chatScrollContainerRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const recognitionRef = useRef<any>(null);

  const activeSession = sessions.find((s) => s.id === activeId) || sessions[0];

  // Sync activeSessionId with storage
  useEffect(() => {
    if (activeId) {
      setActiveSessionId(activeId);
    }
  }, [activeId]);

  // Save sessions whenever changed
  useEffect(() => {
    saveSessions(sessions);
  }, [sessions]);

  // Auto-scroll on new message
  const scrollToBottom = (smooth = true) => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
    }
  };

  useEffect(() => {
    scrollToBottom(false);
  }, [activeId]);

  useEffect(() => {
    if (isGenerating) {
      scrollToBottom(true);
    }
  }, [activeSession?.messages]);

  // Handle scroll listener to show scroll-to-bottom button
  const handleScroll = () => {
    if (!chatScrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatScrollContainerRef.current;
    const isFarFromBottom = scrollHeight - scrollTop - clientHeight > 180;
    setShowScrollBottom(isFarFromBottom);
  };

  // Adjust textarea height
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [input]);

  // Voice recognition setup with resilient error handling
  const toggleVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setVoiceNotice('Голосовой ввод не поддерживается в вашем браузере.');
      setTimeout(() => setVoiceNotice(null), 4000);
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current?.stop();
      } catch {}
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ru-RU';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceNotice(null);
      };

      recognition.onresult = (event: any) => {
        try {
          const transcript = event.results?.[0]?.[0]?.transcript;
          if (transcript) {
            setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
          }
        } catch {}
        setIsListening(false);
      };

      recognition.onerror = (e: any) => {
        setIsListening(false);
        const errType = e?.error || '';
        // Normal benign termination states: no-speech and aborted
        if (errType === 'no-speech' || errType === 'aborted') {
          return;
        }
        if (errType === 'not-allowed' || errType === 'service-not-allowed') {
          setVoiceNotice('Разрешите доступ к микрофону в браузере для голосового ввода');
          setTimeout(() => setVoiceNotice(null), 5000);
          return;
        }
        console.warn('Speech recognition status:', errType);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListening(false);
      setVoiceNotice('Не удалось включить запись звука.');
      setTimeout(() => setVoiceNotice(null), 4000);
    }
  };

  // Manage Sessions
  const handleNewSession = () => {
    const newSess = createNewSession();
    setSessions((prev) => [newSess, ...prev]);
    setActiveId(newSess.id);
    setTargetUrls([]);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handleDeleteSession = (id: string) => {
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (filtered.length === 0) {
        const fallback = createNewSession();
        setActiveId(fallback.id);
        return [fallback];
      }
      if (activeId === id) {
        setActiveId(filtered[0].id);
      }
      return filtered;
    });
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: newTitle, updatedAt: Date.now() } : s))
    );
  };

  const handleSelectSearchMode = (mode: SearchMode) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === activeId ? { ...s, searchMode: mode } : s))
    );
  };

  const handleToggleWebSearch = () => {
    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeId ? { ...s, webSearchEnabled: !s.webSearchEnabled } : s
      )
    );
  };

  const handleClearChat = () => {
    if (!window.confirm('Очистить все сообщения в текущем диалоге?')) return;
    setSessions((prev) =>
      prev.map((s) => (s.id === activeId ? { ...s, messages: [], updatedAt: Date.now() } : s))
    );
  };

  const handleExportChat = () => {
    if (!activeSession || activeSession.messages.length === 0) return;
    let md = `# ${activeSession.title}\n\n`;
    md += `*Экспортировано из OmniWeb AI • ${new Date().toLocaleString()}*\n\n---\n\n`;

    activeSession.messages.forEach((m) => {
      const speaker = m.role === 'user' ? '👤 Пользователь' : '🤖 OmniWeb AI';
      md += `### ${speaker} (${new Date(m.timestamp).toLocaleTimeString()}):\n\n${m.content}\n\n`;
      if (m.sources && m.sources.length > 0) {
        md += `**Источники:**\n`;
        m.sources.forEach((s) => {
          md += `- [${s.title || s.uri}](${s.uri})\n`;
        });
        md += `\n`;
      }
      md += `---\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${activeSession.title.replace(/[^a-zA-Zа-яА-Я0-9_-]/g, '_')}_chat.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
  };

  // Send message
  const handleSendMessage = async (textToSend?: string, overrideMode?: SearchMode) => {
    const rawText = textToSend !== undefined ? textToSend : input;
    const trimmed = rawText.trim();
    if (!trimmed || isGenerating || !activeSession) return;

    const currentMode = overrideMode || activeSession.searchMode;
    const currentWebSearch = activeSession.webSearchEnabled;

    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    const userMessage: Message = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      content: trimmed,
      timestamp: Date.now(),
      targetUrls: targetUrls.length > 0 ? [...targetUrls] : undefined,
    };

    const assistantPlaceholderId = `msg_bot_${Date.now() + 1}`;
    const assistantMessage: Message = {
      id: assistantPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
      searchMode: currentMode,
    };

    // Update session title if first message
    const isFirstMessage = activeSession.messages.length === 0;
    const newTitle = isFirstMessage
      ? trimmed.slice(0, 36) + (trimmed.length > 36 ? '...' : '')
      : activeSession.title;

    const updatedMessages = [...activeSession.messages, userMessage, assistantMessage];

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeId
          ? {
              ...s,
              title: newTitle,
              messages: updatedMessages,
              searchMode: currentMode,
              updatedAt: Date.now(),
            }
          : s
      )
    );

    setIsGenerating(true);
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // Build conversation history for API
      const apiMessages = [...activeSession.messages, userMessage].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          webSearchEnabled: currentWebSearch,
          searchMode: currentMode,
          targetUrls,
        }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Ошибка сервера: ${res.status}`);
      }

      const reader = res.body?.getReader();
      if (!reader) throw new Error('Не удалось прочитать поток ответа');

      const decoder = new TextDecoder();
      let streamedContent = '';
      let collectedSources: any[] = [];
      let collectedQueries: string[] = [];
      let streamErrorMessage: string | null = null;

      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (!trimmedLine.startsWith('data: ')) continue;
          const jsonStr = trimmedLine.replace('data: ', '');
          let data: any = null;
          try {
            data = JSON.parse(jsonStr);
          } catch {
            continue;
          }

          if (data.type === 'text') {
            streamedContent += data.chunk;
            setSessions((prev) =>
              prev.map((s) => {
                if (s.id !== activeId) return s;
                return {
                  ...s,
                  messages: s.messages.map((m) =>
                    m.id === assistantPlaceholderId
                      ? { ...m, content: streamedContent }
                      : m
                  ),
                };
              })
            );
          } else if (data.type === 'done') {
            if (data.sources) collectedSources = data.sources;
            if (data.searchQueries) collectedQueries = data.searchQueries;
          } else if (data.type === 'error') {
            streamErrorMessage = data.error || 'Ошибка при генерации ответа';
            break;
          }
        }

        if (streamErrorMessage) {
          break;
        }
      }

      // Finalize assistant message
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id !== activeId) return s;
          return {
            ...s,
            messages: s.messages.map((m) =>
              m.id === assistantPlaceholderId
                ? {
                    ...m,
                    content: streamedContent,
                    isStreaming: false,
                    sources: collectedSources,
                    searchQueries: collectedQueries,
                    error: streamErrorMessage || undefined,
                  }
                : m
            ),
          };
        })
      );
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User deliberately stopped generation
        setSessions((prev) =>
          prev.map((s) => {
            if (s.id !== activeId) return s;
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === assistantPlaceholderId ? { ...m, isStreaming: false } : m
              ),
            };
          })
        );
      } else {
        const errMsg = err?.message || 'Не удалось получить ответ от ИИ';
        setSessions((prev) =>
          prev.map((s) => {
            if (s.id !== activeId) return s;
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === assistantPlaceholderId
                  ? {
                      ...m,
                      isStreaming: false,
                      error: errMsg,
                      content: m.content || '',
                    }
                  : m
              ),
            };
          })
        );
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const handleRegenerateLast = () => {
    if (!activeSession || activeSession.messages.length < 2 || isGenerating) return;
    const messages = activeSession.messages;
    const lastUserIdx = [...messages].reverse().findIndex((m) => m.role === 'user');
    if (lastUserIdx === -1) return;
    const actualIdx = messages.length - 1 - lastUserIdx;
    const lastUserMsg = messages[actualIdx];

    // Remove all messages from that user message onward to re-trigger
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id !== activeId) return s;
        return {
          ...s,
          messages: s.messages.slice(0, actualIdx),
        };
      })
    );

    // Resend
    setTimeout(() => {
      handleSendMessage(lastUserMsg.content);
    }, 50);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      {/* Sidebar */}
      <Sidebar
        sessions={sessions}
        activeSessionId={activeId}
        onSelectSession={setActiveId}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        activeSearchMode={activeSession?.searchMode || 'all'}
        onSelectSearchMode={handleSelectSearchMode}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full min-w-0 relative bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
        {/* Header */}
        <Header
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(true)}
          title={activeSession?.title || 'Новый диалог'}
          webSearchEnabled={activeSession?.webSearchEnabled ?? true}
          onToggleWebSearch={handleToggleWebSearch}
          searchMode={activeSession?.searchMode || 'all'}
          onOpenUrlModal={() => setIsUrlModalOpen(true)}
          targetUrlsCount={targetUrls.length}
          onExportChat={handleExportChat}
          onClearChat={handleClearChat}
          hasMessages={(activeSession?.messages.length ?? 0) > 0}
        />

        {/* Scrollable Messages Container */}
        <div
          ref={chatScrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-3 sm:px-6 md:px-8 py-6 custom-scrollbar"
        >
          {activeSession?.messages.length === 0 ? (
            <TrendingTopics
              onSelectPrompt={(prompt, mode) => {
                if (mode) handleSelectSearchMode(mode);
                handleSendMessage(prompt, mode);
              }}
            />
          ) : (
            <div className="max-w-4xl mx-auto">
              {activeSession?.messages.map((message, index) => (
                <ChatMessageItem
                  key={message.id}
                  message={message}
                  onRegenerate={handleRegenerateLast}
                  isLast={index === activeSession.messages.length - 1}
                />
              ))}
              <div ref={messagesEndRef} className="h-4" />
            </div>
          )}
        </div>

        {/* Floating Scroll to Bottom Button */}
        {showScrollBottom && (
          <button
            onClick={() => scrollToBottom(true)}
            className="absolute bottom-28 right-6 p-2 rounded-full bg-slate-800/90 hover:bg-slate-700 text-sky-400 border border-slate-700 shadow-xl cursor-pointer transition-transform hover:scale-105 active:scale-95 z-20"
            title="Прокрутить в конец"
          >
            <ArrowDown className="w-4 h-4" />
          </button>
        )}

        {/* Input Bar Area */}
        <div className="p-3 sm:p-4 bg-slate-950/90 border-t border-slate-800/80 backdrop-blur-md shrink-0">
          <div className="max-w-4xl mx-auto">
            {/* Voice Notice Toast */}
            {voiceNotice && (
              <div className="mb-2.5 px-3.5 py-2 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs flex items-center justify-between shadow-md">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{voiceNotice}</span>
                </div>
                <button
                  onClick={() => setVoiceNotice(null)}
                  className="text-amber-400 hover:text-white p-0.5 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Active Links indicator bar if any */}
            {targetUrls.length > 0 && (
              <div className="mb-2 flex items-center justify-between px-3 py-1.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-300">
                <div className="flex items-center gap-1.5 truncate">
                  <Link2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="truncate">
                    ИИ проанализирует ссылки: {targetUrls.join(', ')}
                  </span>
                </div>
                <button
                  onClick={() => setIsUrlModalOpen(true)}
                  className="underline text-[11px] text-emerald-400 hover:text-emerald-200 shrink-0 ml-2 cursor-pointer"
                >
                  Изменить
                </button>
              </div>
            )}

            {/* Input Form Box */}
            <div className="relative rounded-2xl bg-slate-900 border border-slate-700/80 focus-within:border-sky-500/80 focus-within:ring-2 focus-within:ring-sky-500/20 shadow-xl shadow-black/30 transition-all">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Задайте вопрос, запросите свежие новости или анализ сайтов..."
                rows={1}
                className="w-full bg-transparent px-4 pt-3.5 pb-12 text-sm md:text-[15px] text-white placeholder:text-slate-500 focus:outline-none resize-none max-h-44 leading-relaxed"
              />

              {/* Bottom toolbar inside input box */}
              <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between">
                {/* Left quick actions */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleToggleWebSearch}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                      activeSession?.webSearchEnabled
                        ? 'bg-sky-500/20 border-sky-500/40 text-sky-300'
                        : 'bg-slate-800/80 border-slate-700/60 text-slate-500 hover:text-slate-300'
                    }`}
                    title={
                      activeSession?.webSearchEnabled
                        ? 'Веб-поиск активен (Google Search Grounding)'
                        : 'Веб-поиск выключен'
                    }
                  >
                    <Globe className="w-3.5 h-3.5 text-sky-400" />
                    <span className="hidden sm:inline">Веб-поиск</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsUrlModalOpen(true)}
                    className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                      targetUrls.length > 0
                        ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        : 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200'
                    }`}
                    title="Прикрепить ссылки на сайты"
                  >
                    <Link2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={toggleVoiceInput}
                    className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                      isListening
                        ? 'bg-rose-500/20 border-rose-500 text-rose-400 animate-pulse'
                        : 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200'
                    }`}
                    title={isListening ? 'Идет запись речи...' : 'Голосовой ввод'}
                  >
                    {isListening ? (
                      <MicOff className="w-3.5 h-3.5 text-rose-400" />
                    ) : (
                      <Mic className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Right: Send or Stop button */}
                <div className="flex items-center gap-2">
                  {isGenerating ? (
                    <button
                      type="button"
                      onClick={handleStopGeneration}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium shadow-md shadow-rose-900/30 transition-all cursor-pointer"
                      title="Остановить генерацию"
                    >
                      <Square className="w-3.5 h-3.5 fill-current" />
                      <span>Стоп</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSendMessage()}
                      disabled={!input.trim()}
                      className={`flex items-center justify-center w-8 h-8 rounded-xl transition-all ${
                        input.trim()
                          ? 'bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white shadow-md shadow-sky-900/30 cursor-pointer active:scale-95'
                          : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                      }`}
                      title="Отправить сообщение (Enter)"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Disclaimer caption */}
            <div className="mt-2 text-center text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
              <Sparkles className="w-3 h-3 text-sky-400/80" />
              <span>
                OmniWeb AI соединяется со всеми информационными сайтами в реальном времени. Всегда проверяйте критически важные факты.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Target URLs Modal */}
      <UrlInputModal
        isOpen={isUrlModalOpen}
        onClose={() => setIsUrlModalOpen(false)}
        targetUrls={targetUrls}
        onUpdateTargetUrls={setTargetUrls}
      />
    </div>
  );
}
