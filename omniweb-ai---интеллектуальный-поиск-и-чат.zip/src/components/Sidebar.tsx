import React, { useState } from 'react';
import {
  Plus,
  MessageSquare,
  Trash2,
  Edit2,
  Check,
  X,
  Globe,
  Newspaper,
  Cpu,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  Search,
  Radio,
} from 'lucide-react';
import { ChatSession, SearchMode } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  activeSearchMode: SearchMode;
  onSelectSearchMode: (mode: SearchMode) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

const SEARCH_MODES: Array<{
  id: SearchMode;
  name: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}> = [
  {
    id: 'all',
    name: 'Всемирная сеть',
    desc: 'Глобальный поиск по всем сайтам',
    icon: Globe,
    color: 'text-sky-400',
  },
  {
    id: 'news',
    name: 'Новости и медиа',
    desc: 'Свежие мировые события и СМИ',
    icon: Newspaper,
    color: 'text-amber-400',
  },
  {
    id: 'tech',
    name: 'IT и технологии',
    desc: 'ИИ, разработка, гаджеты, код',
    icon: Cpu,
    color: 'text-emerald-400',
  },
  {
    id: 'science',
    name: 'Наука & Космос',
    desc: 'Исследования, статьи, открытия',
    icon: Sparkles,
    color: 'text-purple-400',
  },
  {
    id: 'finance',
    name: 'Рынки & Финансы',
    desc: 'Акции, крипта, курсы валют',
    icon: TrendingUp,
    color: 'text-blue-400',
  },
  {
    id: 'factcheck',
    name: 'Фактчекинг',
    desc: 'Проверка достоверности данных',
    icon: ShieldCheck,
    color: 'text-rose-400',
  },
];

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onRenameSession,
  activeSearchMode,
  onSelectSearchMode,
  isOpenMobile,
  onCloseMobile,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [filterQuery, setFilterQuery] = useState('');

  const handleStartRename = (e: React.MouseEvent, s: ChatSession) => {
    e.stopPropagation();
    setEditingId(s.id);
    setEditTitle(s.title);
  };

  const handleSaveRename = (e: React.MouseEvent | React.FormEvent, id: string) => {
    e.stopPropagation();
    e.preventDefault();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const handleCancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
  };

  const filteredSessions = sessions.filter((s) =>
    s.title.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/70 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed lg:static top-0 bottom-0 left-0 z-50 w-72 md:w-80 bg-slate-950 border-r border-slate-800/80 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-600 to-emerald-400 text-white shadow-md shadow-sky-500/20">
              <Globe className="w-5 h-5" />
              <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="font-bold text-white text-base tracking-tight flex items-center gap-1.5">
                OmniWeb AI
                <span className="text-[10px] uppercase font-semibold px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-400 border border-sky-500/30">
                  Live
                </span>
              </div>
              <div className="text-[11px] text-slate-400">Связь со всеми сайтами мира</div>
            </div>
          </div>

          <button
            onClick={onCloseMobile}
            className="p-1 rounded-lg text-slate-400 hover:text-white lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-3">
          <button
            onClick={() => {
              onNewSession();
              onCloseMobile();
            }}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-medium text-sm shadow-md shadow-sky-900/30 transition-all cursor-pointer group active:scale-[0.99]"
          >
            <Plus className="w-4 h-4 transition-transform group-hover:rotate-90" />
            <span>Новый диалог</span>
          </button>
        </div>

        {/* Search Mode Channels Selector */}
        <div className="px-3 py-1">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2 mb-1.5 flex items-center justify-between">
            <span>Режим поиска & Источники</span>
            <Radio className="w-3 h-3 text-emerald-400" />
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {SEARCH_MODES.map((mode) => {
              const Icon = mode.icon;
              const isSelected = activeSearchMode === mode.id;
              return (
                <button
                  key={mode.id}
                  onClick={() => onSelectSearchMode(mode.id)}
                  className={`flex flex-col items-start p-2 rounded-xl text-left transition-all border ${
                    isSelected
                      ? 'bg-sky-950/40 border-sky-500/50 text-white shadow-sm shadow-sky-900/20'
                      : 'bg-slate-900/40 border-slate-800/70 text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 w-full">
                    <Icon className={`w-3.5 h-3.5 ${mode.color}`} />
                    <span className="text-xs font-medium truncate">{mode.name}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Chat History Section */}
        <div className="flex-1 flex flex-col min-h-0 px-3 pt-3">
          <div className="flex items-center justify-between px-2 mb-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            <span>История диалогов</span>
            <span className="text-[10px] text-slate-500">{sessions.length}</span>
          </div>

          {sessions.length > 4 && (
            <div className="mb-2 px-1">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Поиск по диалогам..."
                  value={filterQuery}
                  onChange={(e) => setFilterQuery(e.target.value)}
                  className="w-full bg-slate-900/80 border border-slate-800 text-xs text-slate-200 pl-8 pr-3 py-1.5 rounded-lg focus:outline-none focus:border-sky-500/50"
                />
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto space-y-1 pr-1 custom-scrollbar">
            {filteredSessions.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">
                {sessions.length === 0 ? 'Нет сохраненных диалогов' : 'Ничего не найдено'}
              </div>
            ) : (
              filteredSessions.map((s) => {
                const isActive = s.id === activeSessionId;
                const isEditing = s.id === editingId;

                return (
                  <div
                    key={s.id}
                    onClick={() => {
                      onSelectSession(s.id);
                      onCloseMobile();
                    }}
                    className={`group relative flex items-center justify-between p-2 rounded-xl text-xs cursor-pointer transition-all border ${
                      isActive
                        ? 'bg-slate-800/90 border-sky-500/40 text-white shadow-sm'
                        : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0 flex-1 mr-1">
                      <MessageSquare
                        className={`w-3.5 h-3.5 shrink-0 ${
                          isActive ? 'text-sky-400' : 'text-slate-500'
                        }`}
                      />

                      {isEditing ? (
                        <form
                          onSubmit={(e) => handleSaveRename(e, s.id)}
                          className="flex items-center gap-1 flex-1"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <input
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            autoFocus
                            className="w-full bg-slate-900 border border-sky-500 text-xs text-white px-1.5 py-0.5 rounded focus:outline-none"
                          />
                          <button
                            type="submit"
                            className="p-1 text-emerald-400 hover:text-emerald-300"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={handleCancelRename}
                            className="p-1 text-slate-400 hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </form>
                      ) : (
                        <span className="truncate font-medium">{s.title || 'Новый диалог'}</span>
                      )}
                    </div>

                    {!isEditing && (
                      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => handleStartRename(e, s)}
                          className="p-1 text-slate-400 hover:text-sky-300 transition-colors"
                          title="Переименовать"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteSession(s.id);
                          }}
                          className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Удалить"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Global Connection Badge Status */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/90 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[11px] font-medium text-slate-300">Сеть подключена</span>
            </div>
            <span className="text-[10px] text-slate-400">Google Search • 2026</span>
          </div>
        </div>
      </aside>
    </>
  );
};
