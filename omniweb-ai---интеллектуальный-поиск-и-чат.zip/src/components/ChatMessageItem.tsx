import React, { useState, useEffect } from 'react';
import {
  Bot,
  User,
  Copy,
  Check,
  Volume2,
  VolumeX,
  RotateCcw,
  AlertTriangle,
  Link2,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Message } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { SourcesBadge } from './SourcesBadge';

interface ChatMessageItemProps {
  message: Message;
  onRegenerate?: () => void;
  isLast?: boolean;
}

export const ChatMessageItem: React.FC<ChatMessageItemProps> = ({
  message,
  onRegenerate,
  isLast,
}) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Rate limit countdown timer
  const isRateLimit = Boolean(
    message.error &&
      (message.error.includes('429') ||
        message.error.includes('Лимит') ||
        message.error.includes('Rate Limit'))
  );
  const [countdown, setCountdown] = useState<number>(15);

  useEffect(() => {
    if (!isRateLimit) return;
    setCountdown(15);
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [message.error, isRateLimit]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  const handleToggleSpeak = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(message.content.replace(/[#*`_]/g, ''));
    utterance.lang = 'ru-RU';
    utterance.rate = 1.05;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const formatTime = (ts: number) => {
    try {
      return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  if (isUser) {
    return (
      <div className="flex justify-end mb-6 group">
        <div className="flex items-start gap-3 max-w-[85%] md:max-w-[75%]">
          <div className="flex flex-col items-end">
            <div className="px-4 py-3 rounded-2xl rounded-tr-sm bg-gradient-to-r from-sky-600 to-blue-600 text-white shadow-md shadow-sky-950/20 text-[15px] leading-relaxed break-words">
              {message.content}
            </div>

            {message.targetUrls && message.targetUrls.length > 0 && (
              <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-sky-400">
                <Link2 className="w-3 h-3" />
                <span>Прикреплено ссылок: {message.targetUrls.length}</span>
              </div>
            )}

            <span className="text-[10px] text-slate-500 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {formatTime(message.timestamp)}
            </span>
          </div>

          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shrink-0 shadow-sm shadow-sky-500/20">
            <User className="w-4 h-4" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start mb-6 group">
      <div className="flex items-start gap-3 max-w-[96%] md:max-w-[88%] w-full">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-sky-500 flex items-center justify-center text-slate-950 font-bold shrink-0 shadow-md shadow-emerald-500/20 mt-1">
          <Bot className="w-4 h-4 text-slate-950" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="text-xs font-semibold text-sky-300 flex items-center gap-1.5">
              <span>OmniWeb AI</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20">
                Live Grounding
              </span>
            </span>
            <span className="text-[10px] text-slate-500">{formatTime(message.timestamp)}</span>
          </div>

          {/* Sources and Search Queries Drawer */}
          <SourcesBadge sources={message.sources} searchQueries={message.searchQueries} />

          {/* Dedicated Rate Limit / Quota Banner */}
          {isRateLimit && (
            <div className="mb-3 p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 text-amber-200 shadow-md">
              <div className="flex items-start gap-2.5">
                <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="flex-1 text-xs space-y-1.5">
                  <div className="font-semibold text-amber-300 text-sm">
                    Синхронизация со всемирной сетью
                  </div>
                  <p className="text-amber-200/90 leading-relaxed">
                    Все запросы бесплатны и доступны без ограничений. Если сеть перегружена, сервис автоматически завершает обработку через несколько секунд.
                  </p>
                  <div className="pt-2 flex items-center gap-3 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-900/50 border border-amber-500/40 text-[11px] font-mono text-amber-300">
                      <Clock className="w-3.5 h-3.5" />
                      {countdown > 0 ? `Повтор доступен через ${countdown} с` : 'Квота обновилась!'}
                    </span>

                    {onRegenerate && (
                      <button
                        onClick={onRegenerate}
                        className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium shadow-sm transition-all cursor-pointer ${
                          countdown === 0
                            ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold animate-pulse'
                            : 'bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/30'
                        }`}
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Повторить запрос</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* General Error notice if not rate limit */}
          {message.error && !isRateLimit && (
            <div className="mb-3 p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="font-medium">{message.error}</div>
                {onRegenerate && (
                  <button
                    onClick={onRegenerate}
                    className="mt-2 inline-flex items-center gap-1 text-[11px] underline text-rose-300 hover:text-white"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Попробовать снова</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Message Content Container (Only render if there is content or actively streaming) */}
          {(message.content || message.isStreaming) && (
            <div className="p-4 md:p-5 rounded-2xl rounded-tl-sm bg-slate-900/80 border border-slate-800/80 shadow-lg shadow-black/20">
              {message.content ? (
                <MarkdownRenderer content={message.content} />
              ) : message.isStreaming ? (
                <div className="flex items-center gap-2 text-slate-400 text-sm py-2">
                  <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                  <span>Поиск по всемирной сети и формирование ответа...</span>
                </div>
              ) : null}

              {message.isStreaming && message.content && (
                <span className="inline-block w-2 h-4 bg-sky-400 animate-pulse ml-1 align-middle" />
              )}
            </div>
          )}

          {/* Assistant message action buttons */}
          {!message.isStreaming && message.content && (
            <div className="flex items-center gap-2 mt-2 text-xs text-slate-400">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                title="Скопировать ответ"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Скопировано</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Копировать</span>
                  </>
                )}
              </button>

              {'speechSynthesis' in window && (
                <button
                  onClick={handleToggleSpeak}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer ${
                    isSpeaking ? 'text-sky-400 bg-sky-950/40' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title={isSpeaking ? 'Остановить речь' : 'Озвучить ответ'}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                      <span className="text-rose-400">Стоп</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Озвучить</span>
                    </>
                  )}
                </button>
              )}

              {isLast && onRegenerate && (
                <button
                  onClick={onRegenerate}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                  title="Повторить генерацию"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Повторить</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
