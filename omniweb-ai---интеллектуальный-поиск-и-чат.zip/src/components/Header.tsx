import React from 'react';
import { Menu, Globe, Link2, Download, Trash, Sparkles } from 'lucide-react';
import { SearchMode } from '../types';

interface HeaderProps {
  onToggleMobileSidebar: () => void;
  title: string;
  webSearchEnabled: boolean;
  onToggleWebSearch: () => void;
  searchMode: SearchMode;
  onOpenUrlModal: () => void;
  targetUrlsCount: number;
  onExportChat: () => void;
  onClearChat: () => void;
  hasMessages: boolean;
}

const MODE_LABELS: Record<SearchMode, { label: string; dotColor: string }> = {
  all: { label: 'Всемирная сеть', dotColor: 'bg-sky-400' },
  news: { label: 'Новости', dotColor: 'bg-amber-400' },
  tech: { label: 'IT & Технологии', dotColor: 'bg-emerald-400' },
  science: { label: 'Наука', dotColor: 'bg-purple-400' },
  finance: { label: 'Финансы', dotColor: 'bg-blue-400' },
  factcheck: { label: 'Фактчекинг', dotColor: 'bg-rose-400' },
};

export const Header: React.FC<HeaderProps> = ({
  onToggleMobileSidebar,
  title,
  webSearchEnabled,
  onToggleWebSearch,
  searchMode,
  onOpenUrlModal,
  targetUrlsCount,
  onExportChat,
  onClearChat,
  hasMessages,
}) => {
  const currentModeInfo = MODE_LABELS[searchMode] || MODE_LABELS.all;

  return (
    <header className="h-14 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md px-3 md:px-5 flex items-center justify-between shrink-0 z-30 sticky top-0">
      {/* Left: Mobile hamburger & title */}
      <div className="flex items-center gap-2.5 min-w-0">
        <button
          onClick={onToggleMobileSidebar}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden cursor-pointer"
          title="Открыть меню"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 min-w-0">
          <h1 className="font-semibold text-slate-100 text-sm md:text-base truncate max-w-[140px] sm:max-w-xs md:max-w-md">
            {title || 'Диалог с OmniWeb AI'}
          </h1>
          <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700/60 text-[11px] text-slate-300">
            <span className={`w-1.5 h-1.5 rounded-full ${currentModeInfo.dotColor}`} />
            <span>{currentModeInfo.label}</span>
          </span>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Web Search Grounding Toggle */}
        <button
          onClick={onToggleWebSearch}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
            webSearchEnabled
              ? 'bg-sky-500/15 border-sky-500/40 text-sky-300 hover:bg-sky-500/25 shadow-xs'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
          title={webSearchEnabled ? 'Веб-поиск по сайтам активен' : 'Веб-поиск выключен'}
        >
          <Globe
            className={`w-3.5 h-3.5 transition-transform ${
              webSearchEnabled ? 'text-sky-400 animate-spin-slow' : 'text-slate-500'
            }`}
          />
          <span className="hidden xs:inline">{webSearchEnabled ? 'Поиск: ВКЛ' : 'Поиск: ВЫКЛ'}</span>
        </button>

        {/* Target URL context button */}
        <button
          onClick={onOpenUrlModal}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
            targetUrlsCount > 0
              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
          title="Прикрепить ссылки на сайты для глубокого анализа"
        >
          <Link2 className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">
            {targetUrlsCount > 0 ? `Ссылки (${targetUrlsCount})` : 'Добавить ссылку'}
          </span>
          {targetUrlsCount > 0 && (
            <span className="sm:hidden px-1 rounded-full bg-emerald-500 text-slate-950 font-bold text-[10px]">
              {targetUrlsCount}
            </span>
          )}
        </button>

        {hasMessages && (
          <>
            {/* Export chat */}
            <button
              onClick={onExportChat}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Экспортировать диалог в Markdown"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Clear messages */}
            <button
              onClick={onClearChat}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors cursor-pointer"
              title="Очистить сообщения диалога"
            >
              <Trash className="w-4 h-4" />
            </button>
          </>
        )}
      </div>
    </header>
  );
};
