import React from 'react';
import {
  Globe,
  Newspaper,
  Cpu,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { SearchMode } from '../types';

interface TrendingTopicsProps {
  onSelectPrompt: (prompt: string, mode?: SearchMode) => void;
}

const PRESET_TOPICS = [
  {
    category: 'Новости & События',
    mode: 'news' as SearchMode,
    icon: Newspaper,
    color: 'from-amber-500/20 to-orange-500/10 border-amber-500/30 text-amber-300',
    title: 'Главные мировые события сегодня',
    desc: 'Сводка свежих новостей из ведущих мировых информационных агентств.',
    prompt: 'Сделай подробную сводку главных мировых новостей и событий за сегодня по данным международных информационных агентств.',
  },
  {
    category: 'Технологии & ИИ',
    mode: 'tech' as SearchMode,
    icon: Cpu,
    color: 'from-emerald-500/20 to-teal-500/10 border-emerald-500/30 text-emerald-300',
    title: 'Прорывы в сфере искусственного интеллекта',
    desc: 'Новые модели, open-source релизы, аппаратные чипы и инновации.',
    prompt: 'Какие главные прорывы и новости в индустрии ИИ и нейросетей появились за последнее время? Приведи данные с tech-порталов и блогов разработчиков.',
  },
  {
    category: 'Рынки & Экономика',
    mode: 'finance' as SearchMode,
    icon: TrendingUp,
    color: 'from-blue-500/20 to-cyan-500/10 border-blue-500/30 text-blue-300',
    title: 'Динамика рынков и курсов валют',
    desc: 'Финансовые сводки, ключевые индексы, нефть, золото и криптоактивы.',
    prompt: 'Какова текущая ситуация на мировых финансовых рынках? Расскажи о динамике курсов ключевых валют, акций и крипторынка с экономическим анализом.',
  },
  {
    category: 'Наука & Космос',
    mode: 'science' as SearchMode,
    icon: Sparkles,
    color: 'from-purple-500/20 to-indigo-500/10 border-purple-500/30 text-purple-300',
    title: 'Свежие открытия в космосе и науке',
    desc: 'Данные телескопов, космических миссий, публикации в Nature и ArXiv.',
    prompt: 'Расскажи о самых захватывающих и важных научных открытиях и астрономических наблюдениях последнего времени.',
  },
  {
    category: 'Фактчекинг & Аналитика',
    mode: 'factcheck' as SearchMode,
    icon: ShieldCheck,
    color: 'from-rose-500/20 to-pink-500/10 border-rose-500/30 text-rose-300',
    title: 'Проверить факты и достоверность новости',
    desc: 'Сверка источников, выявление фейков и оценка надежности информации.',
    prompt: 'Как эксперт по фактчекингу, расскажи, как сейчас проверяются спорные утверждения в интернете, и разбери пример свежего громкого инфоповода.',
  },
  {
    category: 'Глобальный поиск',
    mode: 'all' as SearchMode,
    icon: Globe,
    color: 'from-sky-500/20 to-blue-500/10 border-sky-500/30 text-sky-300',
    title: 'Исследовать любую тему в паутине',
    desc: 'ИИ найдет первоисточники, сопоставит сайты и даст структурированный ответ.',
    prompt: 'Объясни простыми словами, как работает квантовая запутанность и квантовые компьютеры, с примерами и ссылками на авторитетные образовательные сайты.',
  },
];

const INFORMATION_PARTNERS = [
  'Google Search Grounding',
  'Reuters',
  'AP News',
  'Bloomberg',
  'Wikipedia',
  'Nature & Science',
  'TechCrunch',
  'Habr',
  'ArXiv',
  'BBC',
  'GitHub',
  'РБК & ТАСС',
];

export const TrendingTopics: React.FC<TrendingTopicsProps> = ({ onSelectPrompt }) => {
  return (
    <div className="max-w-4xl mx-auto py-6 px-4 flex flex-col items-center text-center">
      {/* Live Badge */}
      <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-700/80 text-xs font-medium text-slate-300 mb-5 shadow-sm">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
        </span>
        <span className="text-slate-300">Прямое подключение к мировым информационным сайтам</span>
      </div>

      {/* Hero Title */}
      <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight mb-3">
        Интеллектуальный поиск &amp; Живой диалог
      </h2>
      <p className="text-sm md:text-base text-slate-400 max-w-2xl mb-8 leading-relaxed">
        Задавайте любые вопросы, получайте актуальные новости, глубокий анализ фактов
        и проверяйте информацию со всего интернета с прямыми ссылками на первоисточники.
      </p>

      {/* Grid of Starter Topics */}
      <div className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 text-left mb-8">
        {PRESET_TOPICS.map((topic, idx) => {
          const Icon = topic.icon;
          return (
            <button
              key={idx}
              onClick={() => onSelectPrompt(topic.prompt, topic.mode)}
              className={`p-4 rounded-2xl bg-gradient-to-br ${topic.color} bg-slate-900/60 border hover:border-sky-400/50 hover:bg-slate-800/80 transition-all duration-200 cursor-pointer text-left group flex flex-col justify-between shadow-lg shadow-black/20 hover:-translate-y-0.5 active:translate-y-0`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold uppercase tracking-wider opacity-90 flex items-center gap-1.5">
                    <Icon className="w-3.5 h-3.5" />
                    <span>{topic.category}</span>
                  </span>
                  <Zap className="w-3 h-3 opacity-40 group-hover:opacity-100 group-hover:text-amber-400 transition-opacity" />
                </div>
                <div className="font-semibold text-slate-100 group-hover:text-sky-300 text-sm mb-1.5 transition-colors">
                  {topic.title}
                </div>
                <div className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {topic.desc}
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400 group-hover:text-sky-300">
                <span>Начать запрос</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </button>
          );
        })}
      </div>

      {/* Supported / Connected Portals Ticker */}
      <div className="w-full max-w-3xl pt-4 border-t border-slate-800/60 text-center">
        <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2.5">
          Информационная экосистема &amp; Живые источники
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2">
          {INFORMATION_PARTNERS.map((partner, i) => (
            <span
              key={i}
              className="px-2.5 py-1 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-400 text-xs font-medium hover:border-slate-700 hover:text-slate-300 transition-colors"
            >
              {partner}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
