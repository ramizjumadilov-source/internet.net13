import React, { useState } from 'react';
import { Globe, ExternalLink, ChevronDown, ChevronUp, Search } from 'lucide-react';
import { GroundingSource } from '../types';

interface SourcesBadgeProps {
  sources?: GroundingSource[];
  searchQueries?: string[];
}

export const SourcesBadge: React.FC<SourcesBadgeProps> = ({ sources = [], searchQueries = [] }) => {
  const [isOpen, setIsOpen] = useState(false);

  if ((!sources || sources.length === 0) && (!searchQueries || searchQueries.length === 0)) {
    return null;
  }

  // Deduplicate sources by URI
  const uniqueSources = sources.filter(
    (src, index, self) =>
      src.uri && index === self.findIndex((s) => s.uri?.toLowerCase() === src.uri?.toLowerCase())
  );

  return (
    <div className="mb-3 rounded-xl border border-sky-500/20 bg-sky-950/20 backdrop-blur-sm overflow-hidden text-xs transition-all">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-3.5 py-2 text-left hover:bg-sky-500/10 transition-colors"
      >
        <div className="flex items-center gap-2 flex-wrap text-sky-300">
          <Globe className="w-4 h-4 text-sky-400 shrink-0" />
          <span className="font-medium">
            Использовано информационных сайтов: {uniqueSources.length}
          </span>
          {searchQueries.length > 0 && (
            <span className="text-slate-400">
              • Запросов в сети: {searchQueries.length}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 text-slate-400">
          <span>{isOpen ? 'Скрыть' : 'Показать'}</span>
          {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </div>
      </button>

      {isOpen && (
        <div className="p-3 border-t border-sky-500/20 bg-slate-900/60 space-y-2.5">
          {searchQueries.length > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Search className="w-3 h-3 text-sky-400" />
                <span>Поисковые запросы ИИ:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {searchQueries.map((q, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-800/90 text-sky-200 border border-slate-700/60 text-[11px]"
                  >
                    "{q}"
                  </span>
                ))}
              </div>
            </div>
          )}

          {uniqueSources.length > 0 && (
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Первоисточники и публикации:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {uniqueSources.map((source, idx) => {
                  let hostname = '';
                  try {
                    if (source.uri) {
                      hostname = new URL(source.uri).hostname.replace('www.', '');
                    }
                  } catch {
                    hostname = 'Сайт';
                  }

                  const faviconUrl = hostname
                    ? `https://www.google.com/s2/favicons?domain=${hostname}&sz=32`
                    : null;

                  return (
                    <a
                      key={idx}
                      href={source.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-start gap-2.5 p-2 rounded-lg bg-slate-800/60 hover:bg-sky-950/40 border border-slate-700/50 hover:border-sky-500/40 transition-all text-slate-200"
                    >
                      {faviconUrl ? (
                        <img
                          src={faviconUrl}
                          alt=""
                          className="w-4 h-4 rounded mt-0.5 shrink-0 opacity-80 group-hover:opacity-100"
                          onError={(e) => {
                            (e.currentTarget as HTMLImageElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <Globe className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="font-medium text-slate-200 group-hover:text-sky-300 truncate text-xs transition-colors">
                          {source.title || hostname}
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1 truncate">
                          <span>{hostname}</span>
                          <ExternalLink className="w-2.5 h-2.5 opacity-60 group-hover:opacity-100" />
                        </div>
                      </div>
                    </a>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
