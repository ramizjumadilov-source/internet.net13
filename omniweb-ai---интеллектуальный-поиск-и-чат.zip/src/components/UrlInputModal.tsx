import React, { useState } from 'react';
import { X, Link2, Plus, Trash2, Globe, CheckCircle } from 'lucide-react';

interface UrlInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUrls: string[];
  onUpdateTargetUrls: (urls: string[]) => void;
}

export const UrlInputModal: React.FC<UrlInputModalProps> = ({
  isOpen,
  onClose,
  targetUrls,
  onUpdateTargetUrls,
}) => {
  const [inputUrl, setInputUrl] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    let trimmed = inputUrl.trim();
    if (!trimmed) return;

    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      trimmed = 'https://' + trimmed;
    }

    try {
      new URL(trimmed);
      if (targetUrls.includes(trimmed)) {
        setError('Эта ссылка уже добавлена');
        return;
      }
      onUpdateTargetUrls([...targetUrls, trimmed]);
      setInputUrl('');
    } catch {
      setError('Пожалуйста, введите корректный адрес сайта (URL)');
    }
  };

  const handleRemove = (urlToRemove: string) => {
    onUpdateTargetUrls(targetUrls.filter((u) => u !== urlToRemove));
  };

  const handleClearAll = () => {
    onUpdateTargetUrls([]);
  };

  const popularSites = [
    { label: 'Википедия', url: 'https://ru.wikipedia.org' },
    { label: 'Reuters News', url: 'https://www.reuters.com' },
    { label: 'Хабр IT', url: 'https://habr.com' },
    { label: 'Nature Science', url: 'https://www.nature.com' },
    { label: 'РБК Главное', url: 'https://www.rbc.ru' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-semibold">
            <Link2 className="w-5 h-5 text-emerald-400" />
            <span>Целевые веб-сайты и статьи</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-sm">
          <p className="text-slate-400 text-xs leading-relaxed">
            Добавьте прямые ссылки на новостные статьи, порталы или документацию.
            ИИ будет обращаться к содержимому этих сайтов при ответе на ваши вопросы.
          </p>

          {/* Input Form */}
          <form onSubmit={handleAdd} className="space-y-2">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Globe className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={inputUrl}
                  onChange={(e) => {
                    setInputUrl(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="https://example.com/article..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs placeholder:text-slate-600 focus:outline-none focus:border-sky-500"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Добавить</span>
              </button>
            </div>
            {error && <div className="text-rose-400 text-xs">{error}</div>}
          </form>

          {/* Quick suggestions */}
          <div>
            <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Быстрый выбор информационных порталов:
            </div>
            <div className="flex flex-wrap gap-1.5">
              {popularSites.map((site, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    if (!targetUrls.includes(site.url)) {
                      onUpdateTargetUrls([...targetUrls, site.url]);
                    }
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-300 text-xs transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3 h-3 text-sky-400" />
                  <span>{site.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Active URLs list */}
          <div className="pt-2">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
              <span>Прикрепленные сайты ({targetUrls.length}):</span>
              {targetUrls.length > 0 && (
                <button
                  onClick={handleClearAll}
                  className="text-rose-400 hover:text-rose-300 normal-case font-normal text-xs cursor-pointer"
                >
                  Очистить все
                </button>
              )}
            </div>

            {targetUrls.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-slate-800 text-center text-xs text-slate-500">
                Ссылки пока не прикреплены. ИИ будет искать информацию по всей открытой сети.
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {targetUrls.map((url, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-0 mr-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="text-slate-200 truncate font-mono text-[11px]">
                        {url}
                      </span>
                    </div>
                    <button
                      onClick={() => handleRemove(url)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition-colors cursor-pointer shrink-0"
                      title="Удалить"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Готово
          </button>
        </div>
      </div>
    </div>
  );
};
