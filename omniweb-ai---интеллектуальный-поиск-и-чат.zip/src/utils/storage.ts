import { ChatSession } from '../types';

const SESSIONS_STORAGE_KEY = 'omniweb_ai_sessions_v1';
const ACTIVE_SESSION_KEY = 'omniweb_ai_active_id_v1';

export function createNewSession(title = 'Новый диалог'): ChatSession {
  const now = Date.now();
  return {
    id: `session_${now}_${Math.random().toString(36).substring(2, 9)}`,
    title,
    messages: [],
    searchMode: 'all',
    webSearchEnabled: true,
    createdAt: now,
    updatedAt: now,
  };
}

export function loadSavedSessions(): ChatSession[] {
  try {
    const raw = localStorage.getItem(SESSIONS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error('Failed to load sessions from localStorage', e);
    return [];
  }
}

export function saveSessions(sessions: ChatSession[]): void {
  try {
    localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
  } catch (e) {
    console.error('Failed to save sessions to localStorage', e);
  }
}

export function getActiveSessionId(): string | null {
  return localStorage.getItem(ACTIVE_SESSION_KEY);
}

export function setActiveSessionId(id: string): void {
  localStorage.setItem(ACTIVE_SESSION_KEY, id);
}
